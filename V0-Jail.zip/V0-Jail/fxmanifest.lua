fx_version 'cerulean'
game 'gta5'

author 'V0samah'
description 'V0 Jail System'
version '2.2.0'

ui_page 'html/index.html'

shared_scripts {
    'config.lua'
}

client_scripts {
    'client/main.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/main.lua'
}

files {
    'html/index.html',
    'html/style.css',
    'html/script.js',
    'html/Sound/*.ogg'
}

lua54 'yes'
