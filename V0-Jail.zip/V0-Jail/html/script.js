class JailTabletApp {
    constructor() {
        this.currentLanguage = 'ar';
        this.isTabletOpen = false;
        this.isJailed = false;
        this.jailTime = 0;
        this.totalJailTime = 0;
        this.jailInterval = null;
        this.audioEnabled = true;
        this.volume = 0.7;
        this.forceHide = false;
        this.lastPlayedSound = { time: 0, name: '' };
        this.isPlayingExitSound = false;
        this.init();
    }

    init() {
        this.initEvents();
        this.updateClock();
        setInterval(() => this.updateClock(), 1000);
        window.addEventListener('message', (event) => this.handleMessage(event));
        this.changeLanguage('ar');
    }

    playSound(soundName) {
        if (!this.audioEnabled) return;
        const now = Date.now();
        if (now - this.lastPlayedSound.time < 500 && this.lastPlayedSound.name === soundName) {
            return;
        }
        try {
            const audio = new Audio(`./Sound/${soundName}.ogg`);
            audio.volume = this.volume;
            audio.play().catch(() => { });
            this.lastPlayedSound = { time: now, name: soundName };
        } catch (error) { }
    }

    playExitSound() {
        if (this.isPlayingExitSound) return;
        this.isPlayingExitSound = true;
        this.playSound('Exitjail');
        setTimeout(() => {
            this.isPlayingExitSound = false;
        }, 2000);
    }

    initEvents() {
        document.getElementById('lang-en')?.addEventListener('click', () => {
            this.playSound('click');
            this.changeLanguage('en');
        });
        document.getElementById('lang-ar')?.addEventListener('click', () => {
            this.playSound('click');
            this.changeLanguage('ar');
        });
        document.getElementById('close-tablet')?.addEventListener('click', () => {
            this.playSound('click');
            this.closeTablet();
        });
        document.getElementById('jail-btn')?.addEventListener('click', () => {
            this.playSound('click');
            this.jailPlayer();
        });
        document.getElementById('unjail-btn')?.addEventListener('click', () => {
            this.playSound('click');
            this.unjailPlayer();
        });
        document.getElementById('test-btn')?.addEventListener('click', () => {
            this.playSound('click');
            this.testJail();
        });
        document.querySelectorAll('.time-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.playSound('click');
                const minutes = e.target.dataset.minutes;
                const jailTimeInput = document.getElementById('jail-time');
                if (jailTimeInput) jailTimeInput.value = minutes;
            });
        });
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.isTabletOpen) {
                this.closeTablet();
            }
        });
    }

    renderReasons(reasons) {
        const grid = document.getElementById('reason-grid');
        if (!grid || !reasons) return;
        grid.innerHTML = '';
        reasons.forEach((reason, index) => {
            const card = document.createElement('div');
            card.className = `reason-card ${index === 0 ? 'active' : ''}`;
            card.dataset.reason = reason.value;
            card.innerHTML = `
                <div class="r-icon"><i class="${reason.icon}"></i></div>
                <div class="r-info">
                    <span class="r-name">${reason.text}</span>
                    <span class="r-tag">${reason.tag}</span>
                </div>
                <div class="card-accent"></div>
            `;
            card.addEventListener('click', (e) => {
                this.playSound('click');
                document.querySelectorAll('.reason-card').forEach(c => c.classList.remove('active'));
                card.classList.add('active');
                const hiddenInput = document.getElementById('selected-reason');
                if (hiddenInput) hiddenInput.value = reason.value;
            });
            grid.appendChild(card);
        });
        if (reasons[0]) {
            const hiddenInput = document.getElementById('selected-reason');
            if (hiddenInput) hiddenInput.value = reasons[0].value;
        }
    }

    showTablet(data) {
        if (this.isJailed) return;
        const tablet = document.getElementById('tablet-ui');
        if (tablet) {
            tablet.classList.add('show');
            this.isTabletOpen = true;
            this.playSound('notification');
            if (data && data.reasons) {
                this.renderReasons(data.reasons);
            }
            if (data && data.coords) {
                document.getElementById('coord-x').textContent = data.coords.x.toFixed(1);
                document.getElementById('coord-y').textContent = data.coords.y.toFixed(1);
                document.getElementById('coord-z').textContent = data.coords.z.toFixed(1);
            }
        }
    }

    hideTablet() {
        const tablet = document.getElementById('tablet-ui');
        if (tablet) {
            tablet.classList.remove('show');
        }
        this.isTabletOpen = false;
    }

    closeTablet() {
        if (window.invokeNative) {
            fetch(`https://${GetParentResourceName()}/closeTablet`, {
                method: 'POST'
            }).catch(() => this.hideTablet());
        } else {
            this.hideTablet();
        }
    }

    changeLanguage(lang) {
        this.currentLanguage = lang;
        document.querySelectorAll('.lang-btn').forEach(btn => btn.classList.remove('active'));
        const langBtn = document.getElementById(`lang-${lang}`);
        if (langBtn) langBtn.classList.add('active');
        document.documentElement.setAttribute('dir', lang === 'ar' ? 'rtl' : 'ltr');
        this.updateLanguageTexts();
    }

    updateLanguageTexts() {
        const texts = this.currentLanguage === 'ar' ? {
            'tablet-title': 'نظام السجن المتطور',
            'tablet-subtitle': 'وحدة التحكم المركزية',
            'control-title': 'إصدار مذكرة سجن',
            'player-label': 'هوية الهدف (ID)',
            'reason-label': 'السبب الموجب للسجن',
            'time-label': 'المدة الزمنية (بالدقائق)',
            'jail-text': 'تنفيذ السجن',
            'unjail-text': 'إطلاق سراح',
            'jail-title': 'قيد الاعتقال',
            'jail-subtitle': 'عقوبة قضائية نشطة',
            'location-title': 'نظام تتبع الـ GPS',
            'stats-title': 'نظرة عامة',
            'total-label': 'السجلات',
            'active-label': 'مسجون',
            'today-label': 'اليوم',
            'logs-title': 'السجل الأمني'
        } : {
            'tablet-title': 'Advanced Jail System',
            'tablet-subtitle': 'Central Control Unit',
            'control-title': 'Issue Jail Warrant',
            'player-label': 'Target Identity (ID)',
            'reason-label': 'Legal Reason for Jail',
            'time-label': 'Time Duration (Minutes)',
            'jail-text': 'Execute Jail',
            'unjail-text': 'Release Player',
            'jail-title': 'UNDER ARREST',
            'jail-subtitle': 'Active Judicial Punishment',
            'location-title': 'GPS Tracking System',
            'stats-title': 'Overview',
            'total-label': 'Total Records',
            'active-label': 'Active Jailed',
            'today-label': 'Today',
            'logs-title': 'Security Log'
        };
        Object.keys(texts).forEach(id => {
            const element = document.getElementById(id);
            if (element) element.textContent = texts[id];
        });
    }

    jailPlayer() {
        const playerId = document.getElementById('player-id')?.value;
        const reason = document.getElementById('selected-reason')?.value;
        const time = document.getElementById('jail-time')?.value;
        if (!playerId || !time) return;
        if (window.invokeNative) {
            fetch(`https://${GetParentResourceName()}/jailPlayer`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    playerId: parseInt(playerId),
                    reason: reason || 'Violation',
                    time: parseInt(time),
                    language: this.currentLanguage
                })
            });
            this.playSound('success');
            this.clearInputs();
        }
    }

    unjailPlayer() {
        const playerId = document.getElementById('player-id')?.value;
        if (!playerId) return;
        if (window.invokeNative) {
            fetch(`https://${GetParentResourceName()}/unjailPlayer`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    playerId: parseInt(playerId),
                    language: this.currentLanguage
                })
            });
            this.playSound('success');
            this.clearInputs();
        }
    }

    testJail() {
        this.showJailUI(30, "Security System Test", "999", "Test Subject", "System Admin", "555");
    }

    showJailUI(time, reason, playerId, playerName, adminName, adminId) {
        this.isJailed = true;
        this.jailTime = time;
        this.totalJailTime = time;
        this.forceHide = false;
        this.hideTablet();
        const hud = document.getElementById('jail-ui');
        if (hud) hud.style.display = 'block';
        document.getElementById('jail-player-id').textContent = playerId;
        document.getElementById('jail-admin-info').textContent = adminName || 'System';
        document.getElementById('jail-reason').textContent = reason || 'Rule Violation';
        this.startJailCountdown();
    }

    startJailCountdown() {
        if (this.jailInterval) clearInterval(this.jailInterval);
        this.jailInterval = setInterval(() => {
            if (this.jailTime > 0) {
                this.jailTime--;
                const minutes = Math.floor(this.jailTime / 60);
                const seconds = this.jailTime % 60;
                document.getElementById('time-digits').textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
                const percent = (this.jailTime / this.totalJailTime) * 100;
                document.querySelector('.progress-bar').style.width = percent + '%';
            } else {
                this.releasePlayer();
            }
        }, 1000);
    }

    releasePlayer() {
        clearInterval(this.jailInterval);
        this.jailInterval = null;
        this.isJailed = false;
        this.playExitSound();
        document.getElementById('jail-ui').style.display = 'none';
        this.forceHide = true;
    }

    updateClock() {
        const now = new Date();
        const timeStr = now.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
        const el = document.getElementById('current-time');
        if (el) el.textContent = timeStr;
    }

    clearInputs() {
        document.getElementById('player-id').value = '';
        document.getElementById('jail-time').value = '';
    }

    handleMessage(event) {
        const data = event.data;
        if (!data || !data.action) return;
        switch (data.action) {
            case 'showTablet': this.showTablet(data); break;
            case 'hideTablet': this.hideTablet(); break;
            case 'showJailUI':
                this.showJailUI(data.time, data.reason, data.playerId, data.playerName, data.adminName, data.adminId);
                break;
            case 'hideJailUI': this.releasePlayer(); break;
            case 'updateJailStats': this.updateStats(data.stats); break;
        }
    }

    updateStats(stats) {
        if (!stats) return;
        document.getElementById('total-jails').textContent = stats.totalJails || 0;
        document.getElementById('active-jails').textContent = stats.activeJails || 0;
        document.getElementById('today-jails').textContent = stats.todayJails || 0;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    window.jailApp = new JailTabletApp();
});