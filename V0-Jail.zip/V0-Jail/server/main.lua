local QBCore = exports['qb-core']:GetCoreObject()
local JailedPlayers = {}
local JailRecords = {}

local WebhookConfig = {
    url = "Youre Weebhook",
    colors = {
        jail = 15548997,
        unjail = 5763719,
        warning = 16776960,
        info = 3447003
    }
}

local function SendDiscordWebhook(title, description, color, fields, username)
    if WebhookConfig.url == "" or WebhookConfig.url == nil then 
        return 
    end
    
    local embed = {
        {
            ["title"] = title,
            ["description"] = description,
            ["color"] = color,
            ["fields"] = fields or {},
            ["footer"] = {
                ["text"] = "V0-Jail System • " .. os.date("%Y/%m/%d %H:%M:%S")
            },
            ["timestamp"] = os.date("!%Y-%m-%dT%H:%M:%SZ")
        }
    }
    
    local payload = {
        username = username or "🔒 V0 Jail System",
        embeds = embed,
        avatar_url = "https://r2.fivemanage.com/PXLXoiKcW65diHvlJVG0X/V0Logo.png"
    }
    
    PerformHttpRequest(WebhookConfig.url, function(err, text, headers)
    end, 'POST', json.encode(payload), { 
        ['Content-Type'] = 'application/json'
    })
end

local function GetPlayerDiscordTag(playerId)
    local identifiers = GetPlayerIdentifiers(playerId)
    if not identifiers then return "N/A" end
    for _, identifier in ipairs(identifiers) do
        if string.find(identifier, "discord:") then
            return "<@" .. string.gsub(identifier, "discord:", "") .. ">"
        end
    end
    return "N/A"
end

local function GetPlayerLicense(playerId)
    local identifiers = GetPlayerIdentifiers(playerId)
    if not identifiers then return "N/A" end
    for _, identifier in ipairs(identifiers) do
        if string.find(identifier, "license:") then
            return identifier
        end
    end
    return "N/A"
end

Citizen.CreateThread(function()
    MySQL.Async.execute([[
        CREATE TABLE IF NOT EXISTS `jail_records` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `citizenid` VARCHAR(50) NOT NULL,
            `player_id` INT NOT NULL,
            `player_name` VARCHAR(100),
            `admin_id` INT NOT NULL,
            `admin_name` VARCHAR(100),
            `reason` VARCHAR(255),
            `jail_time` INT NOT NULL,
            `remaining_time` INT NOT NULL,
            `start_time` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `last_update` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            `time_served` INT DEFAULT 0,
            `released` BOOLEAN DEFAULT FALSE,
            INDEX `citizenid_idx` (`citizenid`),
            INDEX `released_idx` (`released`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]], {})
    
    MySQL.Async.fetchAll('SELECT * FROM jail_records WHERE released = FALSE AND remaining_time > 0', {}, function(result)
        if result then
            for _, data in ipairs(result) do
                local playerId = GetPlayerFromCitizenId(data.citizenid)
                local elapsedMinutes = CalculateOfflineElapsedTime(data.last_update)
                local adjustedRemaining = math.max(0, data.remaining_time - elapsedMinutes)
                
                if adjustedRemaining > 0 then
                    local timeServed = data.jail_time - adjustedRemaining
                    
                    if playerId then
                        JailedPlayers[data.citizenid] = {
                            source = playerId,
                            citizenid = data.citizenid,
                            jailTime = data.jail_time,
                            remainingTime = adjustedRemaining,
                            timeServed = timeServed,
                            reason = data.reason,
                            adminName = data.admin_name,
                            startTime = data.start_time
                        }
                        
                        MySQL.Async.execute('UPDATE jail_records SET remaining_time = ?, time_served = ?, last_update = CURRENT_TIMESTAMP WHERE id = ?', {
                            adjustedRemaining, timeServed, data.id
                        })
                        
                        TriggerClientEvent('v0-jail:sendToJail', playerId, 
                            Config.JailLocation, 
                            adjustedRemaining, 
                            data.reason, 
                            'en',
                            playerId,
                            data.admin_name
                        )
                    else
                        MySQL.Async.execute('UPDATE jail_records SET remaining_time = ?, time_served = ? WHERE id = ?', {
                            adjustedRemaining, timeServed, data.id
                        })
                    end
                else
                    MySQL.Async.execute('UPDATE jail_records SET released = TRUE, remaining_time = 0, time_served = jail_time WHERE id = ?', {
                        data.id
                    })
                end
            end
        end
    end)
end)

function CalculateOfflineElapsedTime(lastUpdate)
    if not lastUpdate then return 0 end
    local lastUpdateTime = os.time(lastUpdate)
    local currentTime = os.time()
    if lastUpdateTime <= 0 then return 0 end
    local timeDiff = currentTime - lastUpdateTime
    local minutesElapsed = math.floor(timeDiff / 60)
    return math.max(0, minutesElapsed)
end

function GetPlayerFromCitizenId(citizenid)
    local players = QBCore.Functions.GetPlayers()
    for _, playerId in ipairs(players) do
        local Player = QBCore.Functions.GetPlayer(playerId)
        if Player and Player.PlayerData.citizenid == citizenid then
            return playerId
        end
    end
    return nil
end

local function SaveJailRecord(citizenid, playerId, playerName, adminId, adminName, reason, jailTime, remainingTime)
    MySQL.Async.execute('DELETE FROM jail_records WHERE citizenid = ? AND released = FALSE', {
        citizenid
    })
    
    MySQL.Async.execute([[
        INSERT INTO jail_records (citizenid, player_id, player_name, admin_id, admin_name, reason, jail_time, remaining_time, time_served)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)
    ]], {
        citizenid, playerId, playerName, adminId, adminName, reason, jailTime, remainingTime
    })
end

QBCore.Functions.CreateCallback('v0-jail:server:CheckPermissions', function(source, cb)
    local Player = QBCore.Functions.GetPlayer(source)
    local isAllowed = false
    
    if Player then
        for _, group in ipairs(Config.AdminGroups) do
            if Player.PlayerData.group == group then
                isAllowed = true
                break
            end
        end
        
        if not isAllowed then
            if IsPlayerAceAllowed(source, 'command.jail') or IsPlayerAceAllowed(source, 'admin') or IsPlayerAceAllowed(source, 'god') then
                isAllowed = true
            end
        end
    end
    
    cb(isAllowed)
end)

QBCore.Functions.CreateCallback('v0-jail:getJailStats', function(source, cb)
    MySQL.Async.fetchScalar('SELECT COUNT(*) FROM jail_records WHERE released = FALSE AND remaining_time > 0', {}, function(activeJails)
        MySQL.Async.fetchScalar('SELECT COUNT(*) FROM jail_records WHERE DATE(start_time) = CURDATE()', {}, function(todayJails)
            MySQL.Async.fetchScalar('SELECT COUNT(*) FROM jail_records', {}, function(totalJails)
                cb({
                    activeJails = activeJails or 0,
                    todayJails = todayJails or 0,
                    totalJails = totalJails or 0
                })
            end)
        end)
    end)
end)

RegisterNetEvent('v0-jail:jailPlayer', function(targetId, reason, time, language)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    local Target = QBCore.Functions.GetPlayer(targetId)

    if not Target then
        TriggerClientEvent('QBCore:Notify', src, "Player not found", "error")
        return
    end

    local isAllowed = false
    if Player then
        for _, group in ipairs(Config.AdminGroups) do
            if Player.PlayerData.group == group then
                isAllowed = true
                break
            end
        end
        if not isAllowed and (IsPlayerAceAllowed(src, 'command.jail') or IsPlayerAceAllowed(src, 'admin') or IsPlayerAceAllowed(src, 'god')) then
            isAllowed = true
        end
    end

    if not isAllowed and not (Config.AllowSelfJail and src == targetId) then
        TriggerClientEvent('QBCore:Notify', src, Config.Languages[language or 'en']['no_permission'], "error")
        return
    end

    local jailTime = tonumber(time)
    if not jailTime or jailTime <= 0 then return end

    MySQL.Async.fetchScalar('SELECT remaining_time FROM jail_records WHERE citizenid = ? AND released = FALSE', {
        Target.PlayerData.citizenid
    }, function(existingTime)
        
        if existingTime and existingTime > 0 then
            TriggerClientEvent('QBCore:Notify', src, "⚠️ Player is already jailed with " .. existingTime .. " minutes remaining", "warning")
            return
        end
        
        SaveJailRecord(
            Target.PlayerData.citizenid,
            targetId,
            Target.PlayerData.charinfo.firstname .. " " .. Target.PlayerData.charinfo.lastname,
            src,
            GetPlayerName(src),
            reason,
            jailTime,
            jailTime
        )
        
        Target.Functions.SetMetaData("injail", jailTime)
        JailedPlayers[Target.PlayerData.citizenid] = {
            source = targetId,
            citizenid = Target.PlayerData.citizenid,
            jailTime = jailTime,
            remainingTime = jailTime,
            timeServed = 0,
            reason = reason,
            adminName = GetPlayerName(src),
            startTime = os.time()
        }

        local adminDiscord = GetPlayerDiscordTag(src)
        local targetDiscord = GetPlayerDiscordTag(targetId)
        local targetLicense = GetPlayerLicense(targetId)
        local adminLicense = GetPlayerLicense(src)
        
        local fields = {
            {name = "👤 المسؤول (Admin)", value = string.format("%s\nFiveM Name: %s\nID: %d\nLicense: %s", adminDiscord, GetPlayerName(src), src, adminLicense), inline = false},
            {name = "🔒 المسجون (Player)", value = string.format("%s\nFiveM Name: %s\nID: %d\nLicense: %s", targetDiscord, GetPlayerName(targetId), targetId, targetLicense), inline = false},
            {name = "⏱️ المدة (Duration)", value = jailTime .. " دقائق", inline = true},
            {name = "📝 السبب (Reason)", value = reason, inline = true}
        }
        
        SendDiscordWebhook("🔒 تم تنفيذ عملية سجن", string.format("قام المسؤول %s بسجن اللاعب %s", adminDiscord, targetDiscord), WebhookConfig.colors.jail, fields, "🔒 نظام سجن آمن")

        TriggerClientEvent('v0-jail:sendToJail', targetId, Config.JailLocation, jailTime, reason, language or 'en', targetId, GetPlayerName(src))
        TriggerClientEvent('QBCore:Notify', src, Config.Languages[language or 'en']['jailed'], "success")
        UpdateJailStats()
    end)
end)

RegisterNetEvent('v0-jail:unjailPlayer', function(targetId, language)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    local Target = QBCore.Functions.GetPlayer(targetId)

    if not Target then
        TriggerClientEvent('QBCore:Notify', src, "Player not found", "error")
        return
    end

    local isAllowed = false
    if Player then
        for _, group in ipairs(Config.AdminGroups) do
            if Player.PlayerData.group == group then
                isAllowed = true
                break
            end
        end
        if not isAllowed and (IsPlayerAceAllowed(src, 'command.jail') or IsPlayerAceAllowed(src, 'admin') or IsPlayerAceAllowed(src, 'god')) then
            isAllowed = true
        end
    end

    if not isAllowed then
        TriggerClientEvent('QBCore:Notify', src, Config.Languages[language or 'en']['no_permission'], "error")
        return
    end

    MySQL.Async.fetchScalar('SELECT remaining_time FROM jail_records WHERE citizenid = ? AND released = FALSE', {
        Target.PlayerData.citizenid
    }, function(remainingTime)
        if not remainingTime or remainingTime <= 0 then
            TriggerClientEvent('QBCore:Notify', src, "Player is not jailed", "error")
            return
        end

        MySQL.Async.execute('UPDATE jail_records SET released = TRUE, remaining_time = 0, time_served = jail_time WHERE citizenid = ?', {
            Target.PlayerData.citizenid
        })

        Target.Functions.SetMetaData("injail", 0)
        JailedPlayers[Target.PlayerData.citizenid] = nil

        local adminDiscord = GetPlayerDiscordTag(src)
        local targetDiscord = GetPlayerDiscordTag(targetId)
        local targetLicense = GetPlayerLicense(targetId)
        local adminLicense = GetPlayerLicense(src)
        
        local fields = {
            {name = "👤 المسؤول (Admin)", value = string.format("%s\nFiveM Name: %s\nID: %d\nLicense: %s", adminDiscord, GetPlayerName(src), src, adminLicense), inline = false},
            {name = "🔓 المحرر (Player)", value = string.format("%s\nFiveM Name: %s\nID: %d\nLicense: %s", targetDiscord, GetPlayerName(targetId), targetId, targetLicense), inline = false},
            {name = "⏱️ الوقت المتبقي الملغى", value = remainingTime .. " دقائق", inline = true}
        }
        
        SendDiscordWebhook("🔓 تم إطلاق سراح لاعب", string.format("قام المسؤول %s بإطلاق سراح اللاعب %s", adminDiscord, targetDiscord), WebhookConfig.colors.unjail, fields, "✅ نظام إدارة السجون")

        TriggerClientEvent('v0-jail:releaseFromJail', targetId, true)
        TriggerClientEvent('QBCore:Notify', src, Config.Languages[language or 'en']['unjailed'], "success")
        UpdateJailStats()
    end)
end)

AddEventHandler('onResourceStart', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end
    Citizen.Wait(2000)
    local players = QBCore.Functions.GetPlayers()
    for _, src in ipairs(players) do
        local Player = QBCore.Functions.GetPlayer(src)
        if Player then
            CheckPlayerJailStatus(src, Player.PlayerData.citizenid)
        end
    end
end)

function CheckPlayerJailStatus(src, citizenid)
    MySQL.Async.fetchAll([[
        SELECT * FROM jail_records 
        WHERE citizenid = ? AND released = FALSE
        ORDER BY start_time DESC LIMIT 1
    ]], {citizenid}, function(result)
        if result and result[1] then
            local data = result[1]
            local elapsedMinutes = CalculateOfflineElapsedTime(data.last_update)
            local newRemaining = math.max(0, data.remaining_time - elapsedMinutes)
            local newTimeServed = data.jail_time - newRemaining
            
            if newRemaining > 0 then
                MySQL.Async.execute('UPDATE jail_records SET remaining_time = ?, time_served = ?, last_update = CURRENT_TIMESTAMP WHERE id = ?', {
                    newRemaining, newTimeServed, data.id
                })
                
                JailedPlayers[citizenid] = {
                    source = src,
                    citizenid = citizenid,
                    jailTime = data.jail_time,
                    remainingTime = newRemaining,
                    timeServed = newTimeServed,
                    reason = data.reason,
                    adminName = data.admin_name,
                    startTime = data.start_time
                }
                
                TriggerClientEvent('v0-jail:sendToJail', src, Config.JailLocation, newRemaining, data.reason, 'en', src, data.admin_name)
            else
                MySQL.Async.execute('UPDATE jail_records SET released = TRUE, remaining_time = 0, time_served = jail_time WHERE id = ?', {
                    data.id
                })
            end
        end
    end)
end

RegisterNetEvent('v0-jail:checkJailStatus', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if Player then
        CheckPlayerJailStatus(src, Player.PlayerData.citizenid)
    end
end)

Citizen.CreateThread(function()
    local dbUpdateTick = 0
    while true do
        Citizen.Wait(1000)
        dbUpdateTick = dbUpdateTick + 1
        
        for citizenid, data in pairs(JailedPlayers) do
            local playerId = data.source
            local Player = QBCore.Functions.GetPlayer(playerId)
            
            if Player and Player.PlayerData.citizenid == citizenid then
                if not data.remainingSeconds then
                    data.remainingSeconds = (data.remainingTime or 0) * 60
                end
                
                if data.remainingSeconds > 0 then
                    data.remainingSeconds = data.remainingSeconds - 1
                    data.remainingTime = math.ceil(data.remainingSeconds / 60)
                    
                    if dbUpdateTick >= 60 or data.remainingSeconds == 0 then
                        Player.Functions.SetMetaData("injail", data.remainingTime)
                        MySQL.Async.execute('UPDATE jail_records SET remaining_time = ?, last_update = CURRENT_TIMESTAMP WHERE citizenid = ? AND released = FALSE', {
                            data.remainingTime, citizenid
                        })
                        
                        TriggerClientEvent('v0-jail:updateJailTimer', playerId, data.remainingTime, data.reason)
                        
                        if data.remainingTime <= 5 and data.remainingTime > 0 then
                            TriggerClientEvent('QBCore:Notify', playerId, string.format("⏰ بقي %d دقائق في السجن", data.remainingTime), "warning", 3000)
                        end
                    end
                    
                    if data.remainingSeconds <= 0 then
                        MySQL.Async.execute('UPDATE jail_records SET released = TRUE, remaining_time = 0, time_served = jail_time WHERE citizenid = ? AND released = FALSE', {
                            citizenid
                        })
                        
                        local targetTag = GetPlayerDiscordTag(playerId)
                        local fields = {
                            {name = "🎮 اللاعب", value = GetPlayerName(playerId) .. " (ID: " .. playerId .. ")", inline = true},
                            {name = "🆔 Discord", value = targetTag, inline = true},
                            {name = "⏱️ مدة العقوبة", value = data.jailTime .. " دقيقة", inline = true}
                        }
                        
                        SendDiscordWebhook("✅ انتهت العقوبة", "أتم اللاعب السجن بالثانية والدقيقة", WebhookConfig.colors.unjail, fields, "✅ نظام العدالة")
                        
                        JailedPlayers[citizenid] = nil
                        Player.Functions.SetMetaData("injail", 0)
                        TriggerClientEvent('v0-jail:releaseFromJail', playerId, true)
                        TriggerClientEvent('QBCore:Notify', playerId, "✅ انتهت مدة سجنك، نرجو الالتزام بالقوانين", "success", 5000)
                    end
                end
            else
                JailedPlayers[citizenid] = nil
            end
        end
        
        if dbUpdateTick >= 60 then 
            dbUpdateTick = 0 
            MySQL.Async.execute([[
                UPDATE jail_records 
                SET released = TRUE, remaining_time = 0, time_served = jail_time
                WHERE released = FALSE AND TIMESTAMPDIFF(MINUTE, last_update, NOW()) >= remaining_time
            ]], {})
            UpdateJailStats()
        end
    end
end)

AddEventHandler('playerDropped', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if Player then
        local citizenid = Player.PlayerData.citizenid
        if JailedPlayers[citizenid] then
            JailedPlayers[citizenid] = nil
        end
    end
end)

function UpdateJailStats()
    MySQL.Async.fetchScalar('SELECT COUNT(*) FROM jail_records WHERE released = FALSE AND remaining_time > 0', {}, function(activeJails)
        MySQL.Async.fetchScalar('SELECT COUNT(*) FROM jail_records WHERE DATE(start_time) = CURDATE()', {}, function(todayJails)
            MySQL.Async.fetchScalar('SELECT COUNT(*) FROM jail_records', {}, function(totalJails)
                local stats = {
                    activeJails = activeJails or 0,
                    todayJails = todayJails or 0,
                    totalJails = totalJails or 0
                }
                
                local players = QBCore.Functions.GetPlayers()
                for _, playerId in ipairs(players) do
                    local Target = QBCore.Functions.GetPlayer(playerId)
                    if Target then
                        local isAllowed = false
                        for _, group in ipairs(Config.AdminGroups) do
                            if Target.PlayerData.group == group then
                                isAllowed = true
                                break
                            end
                        end
                        if isAllowed or IsPlayerAceAllowed(playerId, 'command.jail') or IsPlayerAceAllowed(playerId, 'admin') then
                            TriggerClientEvent('v0-jail:updateJailStats', playerId, stats)
                        end
                    end
                end
            end)
        end)
    end)
end

QBCore.Commands.Add('jailinfo', 'Check jail information', {}, false, function(source)
    local Player = QBCore.Functions.GetPlayer(source)
    if not Player then return end
    
    MySQL.Async.fetchAll([[
        SELECT jail_time, remaining_time, time_served, reason 
        FROM jail_records 
        WHERE citizenid = ? AND released = FALSE 
        ORDER BY start_time DESC LIMIT 1
    ]], {Player.PlayerData.citizenid}, function(result)
        if result and result[1] then
            local data = result[1]
            TriggerClientEvent('QBCore:Notify', source, "📋 Jail Information:\n⏱️ Original: " .. data.jail_time .. " minutes\n✅ Served: " .. data.time_served .. " minutes\n⏳ Remaining: " .. data.remaining_time .. " minutes\n📝 Reason: " .. data.reason, "primary", 10000)
        else
            TriggerClientEvent('QBCore:Notify', source, "✅ You are not in jail", "success")
        end
    end)
end, 'admin')

exports('IsPlayerJailed', function(playerId)
    local Player = QBCore.Functions.GetPlayer(playerId)
    if not Player then return false end
    return JailedPlayers[Player.PlayerData.citizenid] ~= nil
end)

exports('GetJailTime', function(playerId)
    local Player = QBCore.Functions.GetPlayer(playerId)
    if not Player then return 0 end
    if JailedPlayers[Player.PlayerData.citizenid] then
        return JailedPlayers[Player.PlayerData.citizenid].remainingTime
    end
    return 0
end)

RegisterNetEvent('v0-jail:getJailStats', function()
    local src = source
    MySQL.Async.fetchScalar('SELECT COUNT(*) FROM jail_records WHERE released = FALSE AND remaining_time > 0', {}, function(activeJails)
        MySQL.Async.fetchScalar('SELECT COUNT(*) FROM jail_records WHERE DATE(start_time) = CURDATE()', {}, function(todayJails)
            MySQL.Async.fetchScalar('SELECT COUNT(*) FROM jail_records', {}, function(totalJails)
                TriggerClientEvent('v0-jail:updateJailStats', src, {
                    activeJails = activeJails or 0,
                    todayJails = todayJails or 0,
                    totalJails = totalJails or 0
                })
            end)
        end)
    end)
end)

RegisterNetEvent('v0-jail:releaseFromJail', function(autoRelease)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    local citizenid = Player.PlayerData.citizenid
    MySQL.Async.execute('UPDATE jail_records SET released = TRUE, remaining_time = 0 WHERE citizenid = ? AND released = FALSE', {citizenid})
    JailedPlayers[citizenid] = nil
    Player.Functions.SetMetaData("injail", 0)
    UpdateJailStats()
end)

RegisterNetEvent('v0-jail:server:escapeAttempt', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    local name = GetPlayerName(src)
    local citizenid = Player.PlayerData.citizenid
    local players = QBCore.Functions.GetPlayers()
    for _, playerId in ipairs(players) do
        local Target = QBCore.Functions.GetPlayer(playerId)
        if Target and (Target.PlayerData.group == 'admin' or Target.PlayerData.group == 'god' or Target.PlayerData.group == 'owner') then
            TriggerClientEvent('QBCore:Notify', playerId, string.format("⚠️ محاولة هروب: %s (ID: %d)", name, src), "error")
        end
    end
end)