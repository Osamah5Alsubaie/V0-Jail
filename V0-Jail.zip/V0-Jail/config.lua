Config = {}

Config.JailLocation = vector3(354.54, -1408.31, 75.17)
Config.ExitArea = vector3(298.74, -585.94, 42.26)
Config.JailRadius = 15.0

Config.AllowSelfJail = true
Config.SaveJailTime = true
Config.AutoSaveInterval = 30

Config.JailReasons = {
    { text = 'قتل عشوائي', tag = 'RDM / Deathmatch', icon = 'fas fa-skull-crossbones', value = 'RDM' },
    { text = 'سلوك تخريبي', tag = 'Trolling / Griefing', icon = 'fas fa-mask', value = 'Troll' },
    { text = 'اختراق الثغرات', tag = 'Bug Abuse / Exploiting', icon = 'fas fa-virus-slash', value = 'Bug' },
    { text = 'مخالفة عامة', tag = 'Misc / Rules', icon = 'fas fa-exclamation-triangle', value = 'Other' }
}

Config.AdminGroups = {
    'admin',
    'mod',
    'god',
    'owner'
}